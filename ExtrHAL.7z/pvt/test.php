<?php
echo('Accès ok !');
?>